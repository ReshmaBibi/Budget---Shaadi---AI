function calculateBudget() {
  let budget = document.getElementById("budget").value;
  let suggestions = document.getElementById("suggestions");
  let usd = (budget / 83).toFixed(2);
  let eur = (budget / 90).toFixed(2);
  let gbp = (budget / 105).toFixed(2);

  if (budget < 50000) {
    suggestions.innerHTML = `<h3>BUDGET WEDDING PLAN</h3>
        <p>💒 VENUE: COMMUNITY HALL (₹10K)<br>
        🎉 DECOR: DIY (₹5K)<br>
        🍲 FOOD: LOCAL CATERER (₹20K)<br>
        🎵 MUSIC: BLUETOOTH SPEAKER (₹1K)<br>
        💍 ATTIRE: RENT (₹5K)<br>
        📸 PHOTOGRAPHY: FRIEND WITH DSLR (₹5K)</p>`;
  } else if (budget < 200000) {
    suggestions.innerHTML = `<h3>MID-RANGE WEDDING PLAN</h3>
        <p>💒 VENUE: BANQUET HALL (₹50K)<br>
        🎉 DECOR: PROFESSIONAL SETUP (₹30K)<br>
        🍲 FOOD: PREMIUM CATERER (₹80K)<br>
        🎵 MUSIC: DJ (₹15K)<br>
        💍 ATTIRE: CUSTOM OUTFIT (₹10K)<br>
        📸 PHOTOGRAPHY: PROFESSIONAL (₹15K)</p>`;
  } else {
    suggestions.innerHTML = `<h3>LUXURY WEDDING PLAN</h3>
        <p>💒 VENUE: 5-STAR HOTEL (₹3L)<br>
        🎉 DECOR: LUXURY SETUP (₹2L)<br>
        🍲 FOOD: CELEBRITY CHEF (₹3L)<br>
        🎵 MUSIC: LIVE BAND (₹1L)<br>
        💍 ATTIRE: DESIGNER WEAR (₹2L)<br>
        📸 PHOTOGRAPHY: PREMIUM CINEMATIC (₹2L)</p>`;
  }
  suggestions.innerHTML += `<p>🌎 Approximate cost in other currencies:<br>
    💵 USD: $${usd}<br>
    💶 EUR: €${eur}<br>
    💷 GBP: £${gbp}</p>`;
}
